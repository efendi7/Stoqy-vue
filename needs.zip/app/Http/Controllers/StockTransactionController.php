<?php

namespace App\Http\Controllers;

use App\Models\StockTransaction;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;

class StockTransactionController extends Controller
{
    // Metode untuk melihat daftar transaksi
    public function index()
    {
        $transactions = StockTransaction::with('product', 'user')->get();
        return view('stock_transactions.index', compact('transactions'));
    }

    // Metode untuk membuat transaksi baru
    public function create()
    {
        $products = Product::all();
        $users = User::all();
        return view('stock_transactions.create', compact('products', 'users'));
    }

    // Metode untuk menyimpan transaksi baru
    public function store(Request $request)
    {
        StockTransaction::create($request->all());
        return redirect()->route('stock_transactions.index');
    }

    // Metode untuk mengedit transaksi
    public function edit($id)
    {
        $transaction = StockTransaction::find($id);
        $products = Product::all();
        $users = User::all();
        return view('stock_transactions.edit', compact('transaction', 'products', 'users'));
    }

    // Metode untuk memperbarui transaksi
    public function update(Request $request, $id)
    {
        $transaction = StockTransaction::find($id);
        $transaction->update($request->all());
        return redirect()->route('stock_transactions.index');
    }

    // Metode untuk menghapus transaksi
    public function destroy($id)
    {
        StockTransaction::destroy($id);
        return redirect()->route('stock_transactions.index');
    }
}
