@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Daftar Transaksi Stok</h1>
    <a href="{{ route('stock_transactions.create') }}" class="btn btn-primary">Tambah Transaksi</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Produk</th>
                <th>Pengguna</th>
                <th>Jenis</th>
                <th>Jumlah</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($transactions as $transaction)
                <tr>
                    <td>{{ $transaction->id }}</td>
                    <td>{{ $transaction->product->name }}</td>
                    <td>{{ $transaction->user->name }}</td>
                    <td>{{ $transaction->type }}</td>
                    <td>{{ $transaction->quantity }}</td>
                    <td>{{ $transaction->date }}</td>
                    <td>{{ $transaction->status }}</td>
                    <td>
                        <a href="{{ route('stock_transactions.edit', $transaction->id) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('stock_transactions.destroy', $transaction->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
